# Modulus Calculator

Adam Hiatt
10-6-2023

### Overview

This crate provides a (toy) implementation of the RSA algorithm for generated keys, encrypting values, and decrypting values.

### Testing

Using the values supplied in the assignment I wrote an individual test for each one of the functions. Then to make sure everything works end to end, I wrote a test that generates 100 random values and ensures that the encrypt/decrypt functionality works on 100 different sets of keys.

### How'd it go?

Went well, didn't find it too difficult.

### Sources

Both of the class textbooks and the wikipedia article linked within the assignment for the algorithm. No other outside sources.
